package questao1;

public class Instituto {
	private String nome;
	public Aluno aluno;
	public Curso curso;
	
	
	
	
	
	
	
	public String toString() {
		return "Nome: " + nome + ", Aluno: " + aluno + ", Curso:" + curso + ".";
	}
	
	
	

}
