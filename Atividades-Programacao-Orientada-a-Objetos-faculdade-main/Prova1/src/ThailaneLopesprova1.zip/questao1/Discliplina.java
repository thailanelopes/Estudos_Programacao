package questao1;

public class Discliplina {
	private String nome;
	Curso curso;
	
	
	
	
	
	public String toString() {
		return "Nome: " + nome + "Curso: " + curso + ".";
	}
	
	
	 

}
