package questao1;

public class Aluno {
	 private int matricula;
	 private String nome;
	 
	 
	
	public String toString() {
		return "matricula: " + matricula + "Nome: " + nome + ".";
	}
	 
	 


}
