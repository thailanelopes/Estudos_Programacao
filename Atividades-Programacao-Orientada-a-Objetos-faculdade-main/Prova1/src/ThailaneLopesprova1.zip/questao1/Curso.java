package questao1;

public class Curso {
	private String nome;
	public Aluno aluno;
	
	
	
	
	public String toString() {
		return "Nome: " + nome + "Aluno:" + aluno + ".";
	}
	

}
