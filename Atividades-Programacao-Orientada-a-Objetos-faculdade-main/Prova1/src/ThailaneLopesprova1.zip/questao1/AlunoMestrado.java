package questao1;

public class AlunoMestrado extends Aluno {
	private String linhaPesquisa;

	
	
	

	public String toString() {
		return "AlunoMestrado Linha Pesquisa" + linhaPesquisa + ".";
	}
	
	
	
	
	

}
